// import firebase from './firebase';
// // const firebaseConfig = {
// //     apiKey: "AIzaSyAdOx4ri9JgmeZde6rR0ZfhHDs72_Tsikk",
// //     authDomain: "crud-oper-firebase.firebaseapp.com",
// //     projectId: "crud-oper-firebase",
// //     storageBucket: "crud-oper-firebase.appspot.com",
// //     messagingSenderId: "517130951173",
// //     appId: "1:517130951173:web:eaa91ac0f50fe348635a6c"
// //   };
  
// //   // Initialize Firebase
// //   var firebaseDB=firebase.initializeApp(firebaseConfig);
// //   export default  firebaseDB .database().ref();
// // import { getFirestore } from "firebase/firestore";
// // import { initializeApp } from "firebase/app";

// const firebaseConfig = {
//   apiKey: "AIzaSyA-bBakWl8GrayMQPgM0ucNG8s3et2exJU",
//   authDomain: "fir-crud-react-27bc5.firebaseapp.com",
//   projectId: "fir-crud-react-27bc5",
//   storageBucket: "fir-crud-react-27bc5.appspot.com",
//   messagingSenderId: "788047559195",
//   appId: "1:788047559195:web:6d0dcda65b0f89a6f4d6be",
// };

// const app =initializeApp(firebaseConfig);
// const db = getFirestore(app);

// export default db;

// import { getFirestore } from "firebase/firestore";
// import { initializeApp } from "firebase/app";
// const firebaseConfig = {
//   apiKey: "AIzaSyBbABgsuzPVHpYDKxUh8w8GtU4NaqLzPnw",
//   authDomain: "crud-fire-480b2.firebaseapp.com",
//   databaseURL: "https://crud-fire-480b2-default-rtdb.firebaseio.com",
//   projectId: "crud-fire-480b2",
//   storageBucket: "crud-fire-480b2.appspot.com",
//   messagingSenderId: "860939545008",
//   appId: "1:860939545008:web:6c4d40cb0d0c434bb7ce75"
// };
// const app =initializeApp(firebaseConfig);
// const db = getFirestore(app);
// export default db;

import { getFirestore } from "firebase/firestore";
import { initializeApp } from "firebase/app";
const firebaseConfig = {
  apiKey: "AIzaSyD6XVhI8L0spDKs3oiXIME41_Q2du3fHrc",
  authDomain: "crud-fire-base-642e5.firebaseapp.com",
  databaseURL: "https://crud-fire-base-642e5-default-rtdb.firebaseio.com",
  projectId: "crud-fire-base-642e5",
  storageBucket: "crud-fire-base-642e5.appspot.com",
  messagingSenderId: "96203941006",
  appId: "1:96203941006:web:61d41ee6b2354c047655df"
};
const app =initializeApp(firebaseConfig);
const db = getFirestore(app);
export default db;