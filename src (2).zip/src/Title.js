import React from 'react';
    
function TodoSubject(props) {
    return (
        <div className='subject'>
            <h1>Todo Application</h1>
        </div>
    );
}
export default TodoSubject;